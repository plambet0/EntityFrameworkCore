﻿namespace VaporStore.Data
{
	public static class Configuration
	{
		public static string ConnectionString =
			@"Server=.\SQLExpress;Database=VaporStore;Trusted_Connection=True";
	}
}